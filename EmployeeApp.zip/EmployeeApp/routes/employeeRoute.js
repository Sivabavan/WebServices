const express = require('express')
const router = express.Router()
const Employee = require('../models/Employee')
const {default: mongoose} = require('mongoose')
//const {mongoose} = require('mongoose')

router.get('/', async (req,res)=>{
    try{
        const results = await Employee.find().populate("_id")
        if(results){
            res.status(200).json(results)
        } else{
            res.status(404).send("Sorry, No Data Found !")
        }
    } catch(error){
        console.error(error);
        res.status(500).send("Server Error !")
    }
})


router.get('/procount/', async (req,res)=>{
    try{
        const results = await Employee.find()
        const newResults = results.map(emp=>({
            id:emp._id,
            name:emp.empName,
            num_of_projects:emp.prjId.length
        }))
        if(results){
            res.status(200).json(newResults)
        } else{
            res.status(404).send("Sorry, No Data Found !")
        }
    } catch(error){
        console.error(error);
        res.status(500).send("Server Error !")
    }
})




//get project names along with employee details
//get the distinct positions of employees //distinct-get the unique position
//along with distinct positions, shoe how many employees hold that position
//like Engineers:2
//HR:1
router.get('/emp-projects', async (req, res) => {
  try {
    const results = await Employee.find().populate('prjId') // populate project documents

    const formatted = results.map(emp => ({
      employee_id: emp._id,
      employee_name: emp.empName,
      projects: emp.prjId.map(p => p.prjName) // show only project names
    }))

    res.status(200).json(formatted)
  } catch (error) {
    console.error(error)
    res.status(500).send("Server Error!")
  }
})

router.get('/position-counts', async (req, res) => {
  try {
    const results = await Employee.aggregate([
      {
        $group: {
          _id: "$empPosition",
          count: { $sum: 1 }
        }
      },
      {
        $project: {
          position: "$_id",
          count: 1,
          _id: 0
        }
      },
      {
        $sort: { count: -1 } // optional: sort by count descending
      }
    ])

    res.status(200).json(results)
  } catch (error) {
    console.error(error)
    res.status(500).send("Server Error!")
  }
})







module.exports=router